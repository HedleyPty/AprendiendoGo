#Aprendiendo Go (temáticas a tratar)
![Gopher](https://camo.githubusercontent.com/bc8853eda7cbe8b23b35b6b607b15367af9c3c36/68747470733a2f2f7261772e6769746875622e636f6d2f676f6c616e672d73616d706c65732f676f706865722d766563746f722f6d61737465722f676f706865722d66726f6e742e706e67)
#Historia de Go
#Pensamiento algorítmico
#Uso de la revisión de versiones -Github
#Instalación
##Uso de la línea de comandos o terminal
##El parque de juegos (playground)
##Sintaxis básica

#Info
Para bajar las aplicaciones para Windows, Mac, Linux y Android deberás entrar a la carpeta "Distros" y seguir las instrucciones escritas en el archivo LEEME.MD de esa carpeta.

#Advertencia!!
Esta es una versión en desarrollo, por favor no baje los distros hasta que este proyecto esté un poco más maduro

