#Instrucciones
###Baje y descomprima el archivo *Programar_con_Python-1.0-all.zip* en algun sitio de su computadora
#Mac
###Baje el archivo *AprendiendoGo-1.0-linux.win.zip* descomprima la carpeta que tiene dentro. Luego ejectute la aplicación *AprendiendoGo.exe* dentro de la carpeta.
#Mac
###Baje el archivo *AprendiendoGo-1.0-linux.mac.zip* descomprima la carpeta que tiene dentro. Luego ejectute la aplicación *AprendiendoGo.app* dentro de la carpeta.
#MacOS and Linux
###Baje el archivo *AprendiendoGo-1.0-linux.tar.bz2* descomprima la carpeta que tiene dentro. Luego ejectute la aplicación *AprendiendoGo.sh* dentro de la carpeta.

#Android
###Baje el programa con la extensión apk y realice un sideloading, si no sabe como hacerlo, mire la imagen adjunta
![Sideloading](https://dt.azadicdn.com/wp-content/uploads/2014/12/manually-install-Play-Store.png?8632)
 
#Advertencia

Este programa está incompleto, vea el README.md en el directorio raíz donde indico el avance del proyecto

