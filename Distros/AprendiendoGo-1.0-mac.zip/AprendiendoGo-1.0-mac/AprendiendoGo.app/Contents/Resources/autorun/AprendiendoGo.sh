#!/usr/bin
python renpy.py
