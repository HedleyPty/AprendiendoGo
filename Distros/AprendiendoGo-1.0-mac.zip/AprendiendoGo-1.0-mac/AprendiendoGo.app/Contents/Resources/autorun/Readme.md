# Aprendiendo Go (temáticas a tratar)
##Historia de Go
##Pensamiento algorítmico
##Uso de la revisión de versiones -Github
##Instalación
##El parque de juegos (playground)
##Sintaxis básica

#Info
Para bajar las aplicaciones para Windows, Mac, Linux y Android deberás entrar a la carpeta "Distros" y seguir las instrucciones escritas en el archivo LEEME.MD de esa carpeta.

